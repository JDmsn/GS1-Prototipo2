package com.example.jm.buywithme.Model;

/**
 * Created by jm on 17.12.23.
 */

public class Category {
    private int select;
    private String name;
}
